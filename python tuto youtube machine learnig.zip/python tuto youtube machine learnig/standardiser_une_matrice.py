# -*- coding: utf-8 -*-
"""
Created on Sun Jan 31 12:40:43 2021

@author: dell
"""
import numpy as np

# exercice!!! standardiser une matrice
np.random.seed(0)
X=np.random.randint(0,100,[10,5])
print(X)
D=(X-X.mean(axis=0))/X.std(axis=0)
print(D)
print(D.mean(axis=0))
print(D.std(axis=0))
#moy_col=X.mean(axis=0)
#std_col=X.std(axis=0)
#print(moy_col)
#print(std_col)
#print(moy_col[0])
#for i in range(0,X.shape[0]):
#    for j in range(0,X.shape[1]):
#       X[i,j]=X[i,j]-moy_col[j]
#        X[i,j]=X[i,j]/std_col[j]
#print(X)
#print(X.mean(axis=0))