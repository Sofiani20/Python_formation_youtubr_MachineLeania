# -*- coding: utf-8 -*-
"""
Created on Thu Jan 28 15:27:25 2021

@author: dell
"""


# nous allons manipuler les tableaux ndimensions très importants en data

#tout d'abord importons la bibliothèque numpy

import numpy as np

# np.array est un constructeur de tableau
A=np.array([1,2,3]) #A est un objet de la calsse array à 1 dimension
print(A)
print(A.ndim) # renvoie la dimension de A
print(A.shape) # renvoie la structure de A 
print(A.shape[0]) #shape est une tuple!!! à ne pas oublier 

#les deux attribut les plus importants en datascience sont shape et size(nbre elem tableau)
 

# initialisation d'un tableau à ndim 
B=np.zeros((2,3)) # tab 2 lignes 3 colonnes initialisé avec des 0
print(B)
print(B.ndim)
print(B.shape)
print(B.size) #la taille de B i.e le nbre d'element

C=np.ones((4,3)) # tab 4 lines 3 columns by 1
print(C)
print(C.ndim)
print(C.shape)
print(C.size)

D=np.full((2,3),9) # initialise par le nombre qu'on lui précise
print(D)
#une autre initialisation important est:
E=np.random.randn(3,4)# initialisation aléatoire selon la loi normale(0,1)
print(E)

#Pour générer les mêmes nombres on utilise seed
np.random.seed(1) # on peut changer le 0 par un autre nombre pour avoir autre génération
print(np.random.randn(2,3))

print(np.eye(5)) #matrice identité de taille 5

# autres constructeurs pour tab à 1 dim
F=np.linspace(1,10,20) # 20 éléments uniforméments repartis entre 1 et 20
print(F)
G=np.arange(1,10,0.5) # génère des nombre de 1 à 10 avec un pas =0.5
print(G)

#pour tous ces contructeurs on peut préciser le type d'éléments à générer
#par le paramètres dtype

H=np.linspace(1,5,10,dtype=np.float16) # floats 16 bite en memoire, plus rapide mais
print(H)
I=np.linspace(1,5,10,dtype=np.float64)  # moins précis que 64 bites 
print(I)