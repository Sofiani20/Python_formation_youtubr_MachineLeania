# -*- coding: utf-8 -*-
"""
Created on Thu Jan 28 14:39:27 2021

@author: dell
"""


# les comprehensions sont optimales pour écrire du code


liste=[]
liste=range(20)
print(liste)

liste_paire=[]
for i in liste:
    if i%2==0:
        liste_paire.append(i) #stock les nombres paires entre 0 et 20
print(liste_paire)

# optimisons ces instructions par les comprehension!!!

liste_3=[x for x in liste if x%2==0]
print(liste_3)

liste_caractere=[str(x) for x in liste_paire] #tranforms liste_paire elements
print(liste_caractere)                          #into string

dico_fois_2={i: 2*i for i in liste}
print(dico_fois_2)

equipe={'Messi':'Barcelone','Mané':'Liverpool','Cristiano':'Juventus'}
#inversons les clefs par les valeurs du dico equipe
equipe_joueur={equipe[key]: key for key in equipe}
print(equipe_joueur)

