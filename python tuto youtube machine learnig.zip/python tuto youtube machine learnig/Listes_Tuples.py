# -*- coding: utf-8 -*-
"""
Created on Sun Jul 12 12:39:56 2020

@author: dell
"""


# liste
liste_1=[1,4,9,-1,0]
ville=["france","niger","maroc","makka","medine"]
liste_2=[liste_1,ville]  # liste contenant à la fois ma liste 1 et la liste ville
liste_3=[] # crée une liste vide

# Tuple: liste qu'on ne peut pas modifier, ie qui est protégée
tuple_1=(14,9,34,40)
tuple_2=() #tuple vide

# String : chaîne de caractères
nom="sofiani oké"

# Les listes, tuples et string sont tous les 3 des structures de données
# formant des séquences(structure de données qui suit un ORDRE ie les éléments
# sont indexés)

# indexing
print(ville[0]) # affichage de l'élément 1 d'index 0 de la liste ville
print(ville[1]) # second élément de la liste ville
print(ville[-1]) # dernier élément de la liste ville

# slicing
print(ville[1:5])
print(ville[1:4:2])
print(ville[:3]) # éléments du début jusqu'au 3iem elem
print(ville[2:]) # (éléments du deuxième+1) jusqu'au dernier
print(ville[::2])
print(ville[::-1]) # inversion de la liste ville

# realiser des actions sur des listes
ville.append("dublin") # ajouter dublin à la queue de ma liste
ville.insert(2,"Niamey") # placer niamey à l'index 2 de la liste ville
print(ville)
ville_2=["Maradi","Zinder"]
ville.extend(ville_2) #ajout de la liste ville_2 en fin de la liste ville
print(ville)
print(len(ville)) # nbre d'elem de la liste ville
print(ville.count("france")) # compte le nombre de fois que frane apparait dans ville
ville.sort() #trie 
print(ville)
maliste=[1,2,4,5,1,2,1]
print(maliste.count(1)) #compte le nombre de répétition de 1
print(maliste.index(5)) # donne l'indice de 5
maliste.reverse()
print(maliste)
maliste3=maliste+[7,0]
print(maliste3)
maliste3.sort() # tri ordre croissant
print(maliste3)
print(sorted(maliste,reverse=True)) #tri ordre décroissant
machaine="casa:lundi:10"
print(machaine.split(":")) #transforme machaine en liste

if "Niamey" in ville:
    print("voyage en direction de niamey")
else:
    print("dommage!!")
for i in ville:
    print(i)
for index,valeur in enumerate(ville):
    print(index," ",valeur)
for a,b in zip(ville,[1,2,3,4,5,6,7,8]):
    print(a," ",b)


def fibonacci(n):
    if n==0:
        return 0
    elif n==1:
        return 1
    else:
        return (fibonacci(n-1)+fibonacci(n-2))
liste_fubo=[]
for i in range(10):
    liste_fubo.append(fibonacci(i))
print(liste_fubo)

