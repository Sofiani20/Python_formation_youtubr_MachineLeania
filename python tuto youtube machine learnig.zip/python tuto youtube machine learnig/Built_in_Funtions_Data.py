# -*- coding: utf-8 -*-
"""
Created on Mon Jul 13 18:37:34 2020

@author: dell
"""
# valeur absolue
x1=-5
print(abs(x1))
# arrondir
x2=2.6
print(round(x2))

# max/min/longuer/somme/all/any
list_1=[64,-57,12,0]
print(max(list_1))
print(min(list_1))
print(len(list_1))
print(sum(list_1))
list_2=[True,False,False,True]
print(any(list_2))
print(all(list_2))

#conversion d'un type à un autre

x=10
print(x)
print(type(x))
x=str(x)  # conversion de int vers string(str)
print(type(x))
y='20'
y=int(y) # conversion de str en int mais attention c'est ne pas n'importe quel
         # str qui est convertible en int
print(type(y))
y=float(y) #conversion de y en float
print(y)

list_3=[i*3 for i in range(5)]
print(list_3)
tuple_1=tuple(list_3)
print(tuple_1)            # conversion liste vers tuple et tuple vers liste
list_3=list(tuple_1)
print(list_3)

y=input("entrer une valeur: ")
print(type(y)) # attention y est un str il faut penser à le convertir
y=int(input("entrer un valeur: "))
print(type(y))

#fontion format
x=25
ville="arabie"
chn="il fait {} dégré celcus à {}".format(x,ville)
print(chn)
# ou 
chn=f"il fait {x} dégré celcus à {ville}"
print(chn)

import numpy as np
parametres={
    "w1":np.random.randn(2,4),
    "b1":np.zeros((2,1)),
    "w2":np.random.randn(2,2),
    "b2":np.zeros((2,1))
    }
for i in range(1,3):
    print("couche", i)
    print(parametres["w{}".format(i)])
    
# fonction open()
f=open("fichier.txt","w") # ouverture en mode ecriture d'un fichier
f.write("Bonjour")
f.close()
f=open("fichier.txt","r") # mode lecture
print(f.read())
with open("fichier.txt","w") as f:
    for i in range(1,11):
        f.write("  {}^2= {}\n".format(i,i**2)) # write ne prend qu'un seul parametre qui doit
                                  # etre un str
with open("fichier.txt","r") as f:
    print(f.read())
    

        

        


                     