# -*- coding: utf-8 -*-
"""
Created on Sun Jul 12 02:25:29 2020

@author: dell
"""
x=2
y=1
if (x > 0) & (y > x):
    print(x,y," sont tous les deux positifs strictement")
elif (x<=y) & (x<=0) :
    print(x,y," négatifs ")
else: 
    print("bah rien ")
def signe(x):
    """ fontionc donnant le signe de x"""
    if x > 0:
        print("x  = ",x," est positif strictement")
    elif x==0 :
        print("x  = ",x," est nul ")
    else: 
        print("x  = ",x," est négatif strictement")
signe(2)

# boucle for pour repeter n fois un bloc d'instructions
for i in range(5,-5,-1): # range( debut, arrêt, pas)
    signe(i)
# boucle while
def factoriel(n):
    """"factoriel de n"""
    if(n==0 or n==1):
        return 1
    else:
        i=0
        p=1
        while i<n:
            p=p*(n-i)
            i+=1
        return (p)
fac_5=factoriel(6)
print(fac_5)

# suite de fibonacci
def fibonacci(n):
    if n==0:
        return 0
    elif n==1:
        return 1
    else:
        return (fibonacci(n-1)+fibonacci(n-2))
def n_term_fibonacci(n):
    i=0
    while i<=n:
        print(fibonacci(i))
        i+=1
n_term_fibonacci(16)
        
            
            
    
    