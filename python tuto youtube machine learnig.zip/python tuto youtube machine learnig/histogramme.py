# -*- coding: utf-8 -*-
"""
Created on Mon Feb  1 08:56:27 2021

@author: dell
"""


import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris

iris=load_iris() 
type(iris)
x=iris.data # données des 4 variable
y=iris.target # classes 0 1 et 2
plt.figure()
plt.hist(x[:,0],bins=20) # bins pour le nombre de classes
plt.hist(x[:,1],bins=20)
plt.hist(x[:,2],bins=20)
plt.figure()
plt.hist2d(x[:,0],x[:,1],cmap='Blues') #histogramme 2D
plt.xlabel('longueur sepal')
plt.ylabel('largeur sepal')
plt.colorbar() # legender notre hist2D

from scipy import misc
plt.figure()
face=misc.face(gray=True)
#plt.imshow(face,cmap='gray')
plt.hist(face.ravel(),bins=255)
plt.show()