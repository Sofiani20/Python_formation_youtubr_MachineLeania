# -*- coding: utf-8 -*-
"""
Created on Mon Feb  1 08:28:07 2021

@author: dell
"""


import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
iris=load_iris() 
type(iris)
x=iris.data # données des 4 variable
y=iris.target
from mpl_toolkits.mplot3d import Axes3D 
# pour des graphiques 3D, l'OOP est nécessaire pour les 3D avec matplotlib
ax=plt.axes(projection='3d')
ax.scatter(x[:,0],x[:,1],x[:,2],c=y)

f=lambda s,t:np.sin(s)+np.cos(s+t)
S=np.linspace(0,5,100)
T=np.linspace(0,5,100)
S, T=np.meshgrid(S,T)
Z=f(S,T)
AX=plt.axes(projection="3d")
AX.plot_surface(S,T,Z,cmap="plasma")

