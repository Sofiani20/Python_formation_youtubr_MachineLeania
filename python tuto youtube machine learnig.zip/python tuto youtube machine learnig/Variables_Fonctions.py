# -*- coding: utf-8 -*-
"""
Created on Sun Jul 12 01:43:09 2020

@author: dell
"""

x=1
print(x)
x=2
print(x)
y=2.5
# ou bien
x,y=3,2.5
# arithmetique
print(x+y)
print(y**x) # correspond à y exposant x

# comparaison
print(x<=y)
print(x>=y)

# logique
print(False and True)
print(False or True)

# string
nom="sofiani oké"
print(nom)
# Fonction Lambda!! permet la creation de fontions mathematiques
f=lambda x,y : x**2+y
print(f(3,3))

def Energie_Potentielle(m,h,e_lim,g=9.81):
    """ Fonction calculant l'énergie potentielle"""
    E=m*g*h
    if(E<e_lim):
         print("Energie potentielle est : ",E,"J et est en dessous du seuil")
    else: 
         print("Energie potentielle est : ",E,"J et est en dessus du seuil")
               
Energie_Potentielle(100,5,100000.0)


