# -*- coding: utf-8 -*-
"""
Created on Fri Jan 29 21:48:31 2021

@author: dell
"""


import numpy as np

A=np.array([[1,2,3],[4,5,6],[7,8,9]])
print(A)

# INDEXING
print(A[2,1])

# SLICING
print(A[:,0])
print(A[1,:])
print(A[0:2,0:2])
print(A[:,1:3])
B=A[0:2,0:2]
print(B.shape)
A[0:2,0:2]=10
print(A)
C=np.zeros((4,4))
print(C)
print(C[1:3,1:3])
C[1:3,1:3]=1
print(C)
print(C[1:3,1:3])
D=np.zeros((5,5))
print(D)
D[::2,::2]=1
print(D)

#BOOLEAN INDEXING
T=np.random.randint(0,10,[5,5])
print(T)
print(T<5)
T[T<5]=5
print(T)

PIXEL=np.random.randint(0,255,[1000,750])
PIXEL[(PIXEL>200) & (PIXEL <240) ]=241
print(PIXEL)
print(PIXEL[::100,::50])
print(PIXEL[PIXEL<10].size)
N=np.random.rand(1000,750)
print(N[PIXEL>1])

# execice

from scipy import misc
import matplotlib.pyplot as plt
face=misc.face(gray=True)
plt.imshow(face,cmap=plt.cm.gray)
plt.show()
print(type(face))
print(face)
print(face.shape)
#on souhaite zoomer de 1/4 la partie centrale de l'image
hauteur=face.shape[0]
longueur=face.shape[1]
print(hauteur,longueur)
zoom_face=face[hauteur//4:-hauteur//4,longueur//4:-longueur//4] # //: div entière
plt.imshow(zoom_face,cmap=plt.cm.gray)
plt.show()
zoom_face[zoom_face>150]=255 # augmenté la clarté des pixels proche du blanc
plt.imshow(zoom_face,cmap=plt.cm.gray)
plt.show()

