# -*- coding: utf-8 -*-
"""
Created on Mon Jul 13 16:47:16 2020

@author: dell
"""
import time
start=time.time()
liste_1=[]
for i in range(10):        # liste classique
    liste_1.append(i**2)
print(liste_1)
end=time.time()
print(end,start)

 #LISTE COMPREHENSION plus economique en temps en lignes de codes et plus pro
liste_2=[i**2 for i in range(10)]
print(liste_2)            
liste_3=[[i for i in range(3)] for j in range(2)]        
print(liste_3)

# dictionnaire classique
dictionnaire={
    '0':'pierre',
    '1':'jean',
    '2':'julie',
    '3':'sophie'
    }
# dictionnaire comprehension
prenom=['pierre','jean','julie','sophie']
dico={clef:valeur for clef, valeur in enumerate(prenom)}
print(dico)
print(dico.keys())
print(dico.values())

age=[20,45,32,23]
dico_2={prm:ag for prm,ag in zip(prenom,age)}
print(dico_2)
dico_3={prm:ag for prm,ag in zip(prenom,age) if ag<40}
print(dico_3)

tuple_1=(i**2 for i in range(10)) # créer au fait un générateur,
print(tuple_1)                    # concept tres important en python

tuple_2=tuple((i**2 for i in range(10))) # TRANSFORME LE GENERATEUR EN TUPLE
print(tuple_2) 
liste_4=[i for i in range(21)]
print(liste_4)
liste_5=[i**2 for i in liste_4]
print(liste_5)
dico_4={k:v for k,v in zip(liste_4,liste_5)}
print(dico_4)
# ou
carres_pairs={
    str(k):k**2 for k in range(20)
    }
print(carres_pairs)