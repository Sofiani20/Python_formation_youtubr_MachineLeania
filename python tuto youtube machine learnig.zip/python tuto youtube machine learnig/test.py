import os
import random # aleatoire
print(random.randrange(3)) # choix aleatoire d'un nombre entre 0 et 100
M=1
i=0
j=0
k=0
while M<=1000000000:
    rd=random.randrange(3)
    if rd==0:
        i+=1
    elif rd==1:
        j+=1
    else:
        k+=1
    M+=1
print("i= ",i," j= ",j," k= ",k)
os.system("pause")