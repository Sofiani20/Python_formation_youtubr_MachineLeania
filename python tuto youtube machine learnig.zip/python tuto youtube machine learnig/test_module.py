# -*- coding: utf-8 -*-
"""
Created on Tue Jul 14 19:07:48 2020

@author: dell
"""


import module_1 as M1 # importation de tous les constituants du module_1 renommer M1

print(M1.n_term_fibonacci(M1.x))

from module_1 import Energie_Potentielle # imorter uniquement la fonction Ep du 
                                         # module module_1
Energie_Potentielle(15,20)

from module_1 import* # ie importer tout  dans module_1

# liste de module important pour le machine learning
import math # permet de faire en gros les maths
import statistics # faire des statistiques
import random # aleatoire
import os
import glob

#maths
print(math.cos(math.pi))

#statistics
lis=[12,15,17,9]
print(statistics.mean(lis))
print(statistics.variance(lis))

# random 
print(random.choice(lis))
print(random.choice(ville))
#pour obtenir la meme proposition on utlise:
#random.seed(0)
print(random.choice(ville))
print(random.random())# generer un float
print(random.randint(2,4)) # generer un int entre 2 et 4
print(random.randrange(100)) # choix aleatoire d'un nombre entre 0 et 100
print(random.sample(range(100),5)) # choix aleatoire de 5 elements parmi la population
                                   # range(100)
# combinons sample et randrange
print(random.sample(range(100),random.randrange(10)))
random.shuffle(lis) # melange aleatoirement les elements de lis

# OS 
print(os.getcwd()) # pour connaitre notre repertoire de travail

#glob
print(glob.glob("*"))# retourne une liste contenant tous les noms des fichiers qu'on a
# dans notre répertoire de travail
print(glob.glob("*.txt")) # retourne une liste contenant les noms des fichiers .txt
# de mon repertoire de travail

filenames=glob.glob("*.txt")
for file in filenames:
    with open(file,"r") as f:  #afficher le contenu de tout txt de mon repertoire
        print(f.read())



