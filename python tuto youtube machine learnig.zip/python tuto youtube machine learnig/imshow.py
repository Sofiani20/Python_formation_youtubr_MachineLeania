# -*- coding: utf-8 -*-
"""
Created on Mon Feb  1 22:50:43 2021

@author: dell
"""


import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris

from scipy import misc
plt.figure()
face=misc.face(gray=True)
plt.imshow(face) # permet d'afficher des array
plt.show()
iris=load_iris() 
type(iris)
x=iris.data # données des 4 variable
y=iris.target # classes 0 1 et 2
print(x)
plt.figure()
plt.imshow(np.corrcoef(x.T),cmap='Blues')
plt.colorbar()