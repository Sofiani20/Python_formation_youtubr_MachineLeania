# -*- coding: utf-8 -*-
"""
Created on Mon Feb  1 07:49:21 2021

@author: dell
"""

#pour l'exécution des codes voir jupyter


import numpy as np
import matplotlib.pyplot as plt

# SCATTER CLASSIFICATION
#on va charger un dataset très connu load_iris(): des fleurs regroupées en 3
# classes selons 4 variables long et larg cépales et long et larg pétale

from sklearn.datasets import load_iris

iris=load_iris() 
type(iris)
x=iris.data # données des 4 variables
y=iris.target # classes 0 1 et 2
print(x,y)
names=list(iris.target_names)
print(f'x contient {x.shape[0]} données des {x.shape[1]} variables')
print(f'il y a {np.unique(y).size} classes')

# on va représenter deux variables avec plt.scatter et colorer le nuage
# selon la classe
plt.scatter(x[:,0],x[:,1],c=y, alpha=0.5,s=x[:,2]*100) # alpha controle la transparance
                                            # des points et s leur taille
plt.xlabel('longueur sepal')
plt.ylabel('largeur sepal')
