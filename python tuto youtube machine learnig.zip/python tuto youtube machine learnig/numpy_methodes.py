# -*- coding: utf-8 -*-
"""
Created on Thu Jan 28 16:28:38 2021

@author: dell
"""


import numpy as np

A=np.ones((3,5))
print(A)
B=np.zeros((3,2))
print(B)
C=np.hstack((A,B)) # assemble horizontalement A à B(même nbre de lignes!!!!)
print(C)
E=np.zeros((2,5))
D=np.vstack((A,E)) # assemble vertitalement A à E(même nbre de colonnes!!!!)
print(D)

# memes résultats en ulitilisant concatenate
print(np.concatenate((A,E),axis=0)) #verticalement axis=0 
print(np.concatenate((A,B),axis=1)) #horizontalement axis=1

# l'action reshape: il faut que le nombre d'elem soient le mm
print(B.shape)
print(B)
print(B.reshape((2,3))) # 3*2=2*3 (- < -)

# la fonction ravel applati un tableau vers la dim 1

print(D.ravel())


def initialisation(m,n):
    M=np.random.randn(m,n)
    ONE=np.ones((m,1))
    M=np.concatenate((M,ONE),axis=1)
    return M
print(initialisation(3, 2))

    
    
