# -*- coding: utf-8 -*-
"""
Created on Tue Jul 14 19:00:54 2020

@author: dell
"""

ville=["france","niger","maroc","makka","medine"]
nom="sofiani oké"
x=10.0
y=5.0
def fibonacci(n):
    if n==0:
        return 0
    elif n==1:
        return 1
    else:
        return (fibonacci(n-1)+fibonacci(n-2))
    
def n_term_fibonacci(n):
    i=0
    while i<=n:
        print(fibonacci(i))
        i+=1
        
def Energie_Potentielle(m,h,g=9.81):
    """ Fonction calculant l'énergie potentielle"""
    E=m*g*h
    print("Energie potentielle est : ",E,"J")
def factoriel(n):
    """"factoriel de n"""
    if(n==0 or n==1):
        return 1
    else:
        i=0
        p=1
        while i<n:
            p=p*(n-i)
            i+=1
        return (p)