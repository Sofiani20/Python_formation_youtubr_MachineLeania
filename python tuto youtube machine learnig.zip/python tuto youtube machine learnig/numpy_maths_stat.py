# -*- coding: utf-8 -*-
"""
Created on Fri Jan 29 21:48:34 2021

@author: dell
"""
import numpy as np
np.random.seed(0)
A=np.random.randint(0,10,[5,5])
print(A)

# METHODES sum()
print(A.sum()) # somme de tous les éléments de A
print(A.sum(axis=0)) # somme des colonnes
print(A.sum(axis=1)) # somme des lignes

# cumsum() somme cumulée
print(A.cumsum())

#prod() produit des élém
print(A.prod())
print(A.cumprod())

# min() & max()
print(A.min())
print(A.min(axis=0))
print(A.min(axis=1))
print(A.max())
print(A.max(axis=0))
print(A.max(axis=1))

# argmin() et argmax(): retournent les position des min(resp max) sur l'axe
print(A.argmin(axis=0))
print(A.argmax(axis=0))
print(A.argmin(axis=1))
print(A.argmax(axis=1))

# argsort()
print(A.argsort(axis=0))
print(A.argsort(axis=1))

# fonctions mathématiques
print(np.exp(A)) #l'expo des élément de A
# print(np.log(A)) # on a un élément null or log(0) indéterminé
print(np.cos(A)) 
# ainsi de suite ....

# statistiques

print(A.min()) # on a déja vu min max argmin-max et cela selon les axe
#moyenne
print(A.mean())
print(A.mean(axis=0))
# standard deviation n écart-type
print(A.std())
print(A.std(axis=0))
#var()
print(A.var())
print(A.std()**2) # :)
# Matrice de corrélation corrcoef(), pour voir les corrélation entre les lignes
# de la matrice A
print(np.corrcoef(A))
print(np.corrcoef(A)[0,1]) # corr entre L1 et L2
# nombre d'occurence des élément d'un tableau: un comme un tableau xi,ni
print(np.unique(A,return_counts=True))
print(np.unique(A,return_counts=False))
values,count=np.unique(A,return_counts=True)
print(values,count)
print(type(values))
print(values[count.argsort()])

#corriger les nan pour faire les statistiques
B=np.random.randn(5,5)
B[0,2]=np.nan
B[4,3]=np.nan
print(B)
print(np.nanmean(B))
print(np.nanvar(B))
print(np.nanstd(B))
print(np.isnan(B))
def comptenan(A):
    k=0
    B=np.isnan(A)
    for i in range(0,A.shape[0]):
        for j in range(0,A.shape[1]):
            if B[i,j]==True:
                k=k+1
    print(k)
comptenan(B)
# ou
print(np.isnan(B).sum())
#proportion des nan % aux non nan
print(np.isnan(B).sum()/B.size)
#remplacer les nan par des zeros
B[np.isnan(B)]=0
print(B)

#algèbre linéaire
M=np.random.randint(0,10,[2,3])
N=np.random.randint(0,10,[3,2])
print(M,N)
print(M.T) #transposée
print(M.dot(N)) #prod matriciel
print(N.dot(M))
print(np.linalg.det(M.dot(N))) #determinant
print(np.linalg.inv(M.dot(N))) #inverse
print(M.dot(N).dot(np.linalg.inv(M.dot(N)))) # :)
print(np.linalg.eig(M.dot(N))) #valeur prop et vect prop


