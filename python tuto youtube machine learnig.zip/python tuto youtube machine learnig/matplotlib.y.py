# -*- coding: utf-8 -*-
"""
Created on Sun Jan 31 22:55:59 2021

@author: dell
"""


# MATPLOTLIB LIBRAIRIE POUR FAIRE DES GRAPHIQUES
#2 façons de faire à ne pas utiliser en mm temps soit utiliser l'OOP ou une fonction

# fonction
import numpy as np
import matplotlib.pyplot as plt

x=np.linspace(0,2,10)
y=x**2
print(x)
print(y)
plt.figure(figsize=(8,8)) # on peut fixer la taille de nos figures par cet arg
 # pour afficher le graphique on a recourt à:
plt.plot(x,y)
plt.show() # x et y mêmes dimensions!!!!!!!!


# POUR UN NUAGE DE POINT AU UTILISE scatter
#plt.scatter(x,y)

# plot() nous offre plusieurs paramètres pour configurer notre courbe
# l'arg c pour le choix de couleur
# lw pour l'épaisseur du trait
# ls style de trait
plt.plot(x,y,c="red",lw=2,ls='--',label="quadratique")

plt.plot(x,x**3,label="cubique") # superposition de y=x**2 et y=x**3
plt.title('figure1') # on nomme notre graphee
plt.xlabel('axe x')
plt.ylabel("axe y")
plt.legend()
plt.show() # on termine par plt.show()!!!!!!!!
plt.savefig('fig1.JPEG') #pour sauvegarder la fig

# 2 ieme figue
plt.plot(x,y)

# grille de graphique avec l'instruction
# plt.subplot(ligne,colonne,position)
plt.subplot(2,2,1)
plt.plot(x,y)
plt.title('quadratique')
plt.subplot(2,2,2)
plt.plot(x,x**3)
plt.title('cubique')
plt.subplot(2,2,3)
plt.plot(x,np.cos(x))
plt.title('cosinu(x)')

#exercice

dataset={f"experience{i}": np.random.randn(100) for i in range(4) }
def graphique(dataset):
    plt.figure(figsize=(12,8))
    k=1
    for cle,val in dataset.items():
        plt.subplot(4,1,k)
        plt.plot(val)
        plt.title(cle)
        k=k+1


graphique(dataset)
        
