# -*- coding: utf-8 -*-
"""
Created on Sun Jul 12 16:59:24 2020

@author: dell
"""


# les dictionnaires contrairement aux séquence sont des structures de données
# qui ne sont pas ordonnées ie les valeurs ne sont pas indexées mais à la place 
# ont des clefs. NB: on ne paut pas avoir deux clefs identiques dans un mm dictionnaire
# mais les valeurs peuvent se répétées.

Traduction={
    "chien" : "dog",
    "chat" : "mouse",
    "souris" : "mouse",
    "oiseau" : "bird"
    }
Inventaire={
    "banane":285,
    "poires":123456,
    "orange":1236
    }
Nested_Dic={
    "dict_1":Traduction,
    "dict_2":Inventaire
    }
print(Traduction.values()) # voir les valeurs du dic Traduction
print(Inventaire.keys())   # voir les clefs du dic Inventaire
print(len(Nested_Dic))     # voir la taille du dic Nested_Dic

Inventaire["mangue"]=400 # nouvelle clef "mangue" associée à la valeur 400
print(Inventaire)

#Inventaire["peche"] erreur !!
print(Inventaire.get("peche")) #pour savoir si la clef peche est dans mon dico
print(Inventaire.get("orange"))

liste_1=["niamey","zinder","maradi","agadez"]
print(Inventaire.fromkeys(liste_1,"defaut") ) # creer un dico avec comme clefs
                                              # les élements de liste_1 auxquelles
                                              # on associe la valeur "defaut"
for i in Inventaire:
    print(i) # affiche les clefs du dic Inventaire
for i in Inventaire.values(): # pour afficher les valeurs
    print(i)
# pour afficher les clefs ainsi que leurs valeurs:
for clefs,valeurs in Inventaire.items():
    print(clefs, valeurs)
classeur={
    "positif":[],
    "negatif":[]
    }
def trier(classeur,nombre):
    if(nombre<0):
        classeur["negatif"].append(nombre)
    else:
        classeur["positif"].append(nombre)
    return classeur
print(trier(classeur,-5))
print(trier(classeur,5)) 


equipe={'Messi':'Barcelone','Mané':'Liverpool','Cristiano':'Juventus'}
print(equipe)
equipe['Hasard']='Real'
print(equipe)
print(equipe.get('pogba','inconnu'))
print('Messi' in equipe)
del equipe['Hasard'] #supprime hasard
print(equipe)

print(equipe.items()) #couple clefs valeur

for clé,valeur in equipe.items():
    print("le joueur ", clé, "joue dans l'équipe ", valeur)

equipe1={'Neymar':'PSG'}
equipe.update(equipe1) # concatenation de equipe 1 dans equipe
print(equipe)

