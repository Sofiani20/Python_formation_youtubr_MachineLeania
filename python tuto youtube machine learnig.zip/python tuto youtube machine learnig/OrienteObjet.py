# -*- coding: utf-8 -*-
import numpy as np

tab=np.array([1,2,3])

print(tab)

print(tab.size)


